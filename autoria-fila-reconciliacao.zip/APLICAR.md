# Ordem exata de aplicação

Já aplicadas: 20260814200200, 20260814200300, 20260814200400, 20260814201000, 20260814203000.

## 1. SQL Editor — nesta ordem
1. `supabase/migrations/20260814202000_remote_authorship_recovery.sql`
   Cria fila, tabela de lotes, decision, enqueue, split e apply. É esta que faltava.
2. `supabase/migrations/20260814203100_fix_acceptance_and_audit.sql`
   Corrige o critério 4 duplicado e o artefato de LEFT JOIN em fazenda vazia.

## 2. Publicar frontend
- src/pages/SuporteTecnico.tsx        (nova aba "Autoria")
- src/components/tecnico/AuthorshipReconciliationQueue.tsx
- src/components/reports/AutomacaoReportTab.tsx
- src/lib/automationLog.ts

## 3. Montar a fila e conferir
```sql
SELECT public.enqueue_remote_reconciliation();            -- agrupa os 437 em lotes
SELECT * FROM public.remote_authorship_decision();        -- tabela de decisão
SELECT * FROM public.automation_report_acceptance();      -- placar (8 linhas, uma por critério)
SELECT * FROM public.automation_report_farm_audit();      -- panorama por fazenda
```

## 4. Reconciliar
Setor Técnico -> aba **Autoria**: escolher o responsável uma vez por lote e aplicar.
Repetir `automation_report_acceptance()` até toda linha voltar `PASSOU`.

Rollback: `UPDATE public.automation_log SET user_id=NULL, user_email=NULL, actor_label=NULL
WHERE details->>'authorship_source' = 'batch_reconciliation';`
