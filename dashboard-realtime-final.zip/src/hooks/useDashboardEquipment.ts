// ─────────────────────────────────────────────────────────────────────────────
// useDashboardEquipment — fonte única de Pumps/Reservoirs para o Dashboard
// ─────────────────────────────────────────────────────────────────────────────
// - Lê equipamentos reais da nuvem via useCadastrosCloud (filtrados por farm)
// - Reage a updates em tempo real recebidos pelo hook de cadastros
// - Calcula status de comunicação por last_communication (online/instável/offline)
// - Deriva ligado/desligado pelo último payload real de telemetria (last_outputs_state)
// - Não usa Math.random() para status/saídas
//
// IMPORTANTE: ids são UUIDs (string), nunca number.

import { useEffect, useMemo, useRef, useState } from "react";
import { useCadastrosCloud, type CloudEquipamento } from "@/hooks/useCadastrosCloud";
import type { Pump } from "@/components/dashboard/PumpTable";
import type { Reservoir } from "@/components/dashboard/ReservoirGauges";
import { buildCommandHistory, buildStatusHistory, logEvent, useAutomationLog, type AutomationLogEntry } from "@/lib/automationLog";
import { supabase } from "@/integrations/supabase/client";
import { notify } from "@/lib/notify";
import { useDefaultFarmId } from "@/hooks/useDefaultFarmId";
import { calibrateLevel } from "@/lib/levelCalibration";
import { getSystemTimingConfig } from "@/lib/systemTimers";
import { usePendingManualCommands, type PendingManualCommand } from "@/hooks/usePendingManualCommands";

// Janela em que um comando manual em andamento força "Ligando…/Desligando…"
// no card, ignorando last_confirmed_state (que o Electron pode escrever com
// leituras intermediárias durante o reforço).
// FIX dashboard preso: 5min → 120s. O card NUNCA pode aguardar mais que a janela
// operacional. Além disso, o "Ligando/Desligando" só vive enquanto se aguarda a
// CONFIRMAÇÃO FÍSICA — status pending/sent do comando não é confirmação.
const MANUAL_PENDING_WINDOW_MS = 120_000;


// Janela de classificação de comunicação por equipamento.
// REGRA: o equipamento só é OFFLINE após `comm_timeout_minutes` (configurável por
// fazenda, ver setActiveFarmCommTimeout) SEM comunicação real — NÃO após N falhas
// de polling. Interferência momentânea de RF (1–2 ciclos) não derruba o card.
// Fallback (fazenda sem valor carregado): 15 min (1 saída) / 20 min (>1 saída).
// Página web e WhatsApp seguem EXATAMENTE a mesma regra.
const OFFLINE_MIN_SINGLE = 15;
const OFFLINE_MIN_MULTI = 20;

// Timeout de comunicação da fazenda ativa (farms.comm_timeout_minutes, em min).
// Quando definido (>0), sobrepõe o fallback 15/20. O loader em useDashboardEquipment
// atualiza este valor ao trocar de fazenda; o default é 15 (igual ao PLC).
let activeFarmCommTimeoutMin: number | null = null;
export function setActiveFarmCommTimeout(min: number | null | undefined): void {
  activeFarmCommTimeoutMin = (typeof min === "number" && min > 0) ? Math.round(min) : null;
}
// Abaixo deste tempo sem comunicação NÃO é offline — mostramos apenas um indicador
// discreto "⏱ Xmin" (sem alarme): é o último estado conhecido, só faz tempo.
const UNSTABLE_MIN = 2;
const STATUS_REFRESH_MS = 30_000;
// Estados "Ligando…/Desligando…" aguardam a janela física completa antes de
// qualquer falha definitiva. Resposta antiga em 8s NÃO é falha.
// FIX dashboard preso: 5min → 120s. Ao expirar, o card NÃO vira erro: a pendência
// é limpa, o último estado FÍSICO confirmado volta a ser exibido (verde se ON,
// vermelho se OFF) e um aviso NÃO-BLOQUEANTE é mostrado. Timeout de comando
// significa "não confirmado", NUNCA "offline" — o cinza continua sendo decidido
// só por communicationStatus (last_communication vs comm_timeout da fazenda).
const PENDING_MAX_MS = 120_000;
// PROBLEMA 2 — latch anti-oscilação do desligamento forçado. Assim que a bomba
// confirma DESLIGADO FISICAMENTE (last_outputs_state=0) com intenção desligar
// (desired_running=false), o card entra em "Desligado" e AÍ FICA: um RX
// transitório voltando a mostrar 1 (ex.: o pulso {1}→{0} da sequência de
// desligamento forçado) NÃO faz o card voltar para "Ligado"/"Desligando" dentro
// desta janela. Um religamento LOCAL real muda desired_running=true (LOCAL
// OVERRIDE no agente) e libera o latch imediatamente — então não escondemos
// acionamento genuíno.
// v(fix): 30s → 90s — a sequência forçada pode ter até 3 ciclos {1}→RX→{0} e
// levar >30s; a janela precisa cobrir todos os pulsos.
const CONFIRMED_OFF_LATCH_MS = 90_000;

// Aplica o latch: recebe o estado calculado + snapshots e devolve running/pending/
// confirmedOffAt já latcheados. `oldRunning` = running visual anterior;
// `cloudRunning` = realidade física (last_outputs_state) deste tick.
type PumpPending = "turning_on" | "turning_off" | "resetting" | "error" | "comm_fail" | undefined;
function applyConfirmedOffLatch(
  running: boolean,
  pending: PumpPending,
  oldRunning: boolean | undefined,
  oldConfirmedOffAt: number | undefined,
  desiredRunning: boolean | null | undefined,
  cloudRunning: boolean,
): { running: boolean; pending: PumpPending; confirmedOffAt: number | undefined } {
  let confirmedOffAt = oldConfirmedOffAt;
  // FIX PRINCIPAL: desligado CONFIRMADO FISICAMENTE (RX real = 0) + intenção
  // desligar, DENTRO de uma transição de desligamento (estava "Ligado"/"Desligando"
  // ou reset) → marca a confirmação. Isto engata o latch MESMO que um comando
  // manual (ex.: sequência de desligamento forçado) ainda esteja "fresh" na fila
  // segurando o card em "Desligando…". Sem isto, o card ficava preso até o
  // timeout de 5min e virava ERRO ("SEM RESPOSTA") apesar de a bomba ter desligado.
  // A guarda (oldRunning/pending) evita engatar em bombas já em regime DESLIGADO —
  // do contrário um acionamento LOCAL genuíno ficaria escondido pela janela.
  // desiredRunning !== true cobre false E null/undefined — numa bomba local ou
  // remote-desired o desired_running pode não vir estritamente `false` durante o
  // forçado; exigir `=== false` fazia o latch NÃO engatar (bug reportado: o card
  // volta a "LIGADO"/"Desligando"). A guarda (oldRunning/pending) segue impedindo
  // engate em bomba já em regime desligado (não esconde acionamento local).
  if (
    cloudRunning === false && desiredRunning !== true && !confirmedOffAt &&
    (oldRunning === true || pending === "turning_off" || pending === "resetting")
  ) {
    confirmedOffAt = Date.now();
  }
  // Compat: transição visual true → false também marca (quando desired é null).
  if (!running && oldRunning === true && !confirmedOffAt) confirmedOffAt = Date.now();
  // Intenção voltou a LIGAR (religamento real) → libera o latch.
  if (desiredRunning === true) confirmedOffAt = undefined;
  // Dentro da janela + ainda NÃO é religamento (desired !== true) → mantém
  // DESLIGADO estável: não oscila para "Ligado" e não re-exibe "Desligando" por
  // pulsos transitórios. Limpa o pending (tira o card do preso "Desligando…").
  if (confirmedOffAt && (Date.now() - confirmedOffAt < CONFIRMED_OFF_LATCH_MS) && desiredRunning !== true) {
    return { running: false, pending: undefined, confirmedOffAt };
  }
  return { running, pending, confirmedOffAt };
}

export type EquipmentCommunicationStatus = "online" | "unstable" | "offline";

const offlineWindowMs = (outputsInPlc: number | null | undefined): number => {
  if (activeFarmCommTimeoutMin != null) return activeFarmCommTimeoutMin * 60_000;
  return ((outputsInPlc ?? 1) > 1 ? OFFLINE_MIN_MULTI : OFFLINE_MIN_SINGLE) * 60_000;
};

export const getEquipmentCommunicationStatus = (
  lastComm: string | null | undefined,
  outputsInPlc?: number | null,
): EquipmentCommunicationStatus => {
  if (!lastComm) return "online";
  const t = new Date(lastComm).getTime();
  if (Number.isNaN(t)) return "online";

  const diff = Date.now() - t;
  // OFFLINE só depois do timeout de comunicação (proteção do PLC ativa).
  if (diff >= offlineWindowMs(outputsInPlc)) return "offline";
  // Entre UNSTABLE_MIN e o timeout: ainda online, mas com indicador discreto de tempo.
  if (diff >= UNSTABLE_MIN * 60_000) return "unstable";
  return "online";
};



// v3.11.x — Status de comunicação compartilhado por TSNN.
// Toda RX em qualquer saída prova que o PLC está vivo. Portanto, dois
// equipamentos do mesmo plc_group_id devem mostrar o MESMO status de
// comunicação: usamos o MAIS RECENTE `last_communication` entre todos os
// equipamentos do grupo. Isso evita que o Booster 02 (que raramente atua)
// apareça offline enquanto o Booster 01 do mesmo TSNN está respondendo.
export const buildTsnnLastCommMap = (
  equipments: CloudEquipamento[],
): Map<string, string> => {
  const map = new Map<string, string>();
  for (const e of equipments) {
    if (!e.plc_group_id || !e.last_communication) continue;
    const cur = map.get(e.plc_group_id);
    if (!cur || new Date(e.last_communication).getTime() > new Date(cur).getTime()) {
      map.set(e.plc_group_id, e.last_communication);
    }
  }
  return map;
};

const effectiveLastComm = (
  e: CloudEquipamento,
  tsnnMap: Map<string, string>,
): string | null | undefined => {
  if (!e.plc_group_id) return e.last_communication;
  const shared = tsnnMap.get(e.plc_group_id);
  const own = e.last_communication;
  if (!shared) return own;
  if (!own) return shared;
  return new Date(shared).getTime() > new Date(own).getTime() ? shared : own;
};

// Conta saídas por plc_group_id — usado para decidir a janela de OFFLINE
// (15 min single-output / 20 min multi-output).
export const buildPlcOutputsCountMap = (
  equipments: CloudEquipamento[],
  plcs?: Array<{ id: string; output_count?: number | null }>,
): Map<string, number> => {
  const map = new Map<string, number>();
  const knownPlcIds = new Set<string>();
  for (const plc of plcs ?? []) {
    map.set(plc.id, Math.max(1, Number(plc.output_count ?? 1)));
    knownPlcIds.add(plc.id);
  }

  // Fallback para cadastros antigos sem output_count: usa a quantidade de
  // equipamentos ativos no grupo. Se output_count existe, ele prevalece.
  for (const e of equipments) {
    if (!e.plc_group_id) continue;
    if (knownPlcIds.has(e.plc_group_id)) continue;
    map.set(e.plc_group_id, (map.get(e.plc_group_id) ?? 0) + 1);
  }
  return map;
};

const outputsForEquip = (
  e: CloudEquipamento,
  plcCount: Map<string, number>,
): number => (e.plc_group_id ? (plcCount.get(e.plc_group_id) ?? 1) : 1);

// Reservatórios (sensores de nível) usam EXATAMENTE a mesma regra dos demais
// equipamentos — não há mais threshold curto específico para nível.
export const getReservoirCommunicationStatus = getEquipmentCommunicationStatus;


const formatTimestamp = (iso: string | null | undefined): string => {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getFullYear()).slice(-2)} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(date.getSeconds()).padStart(2, "0")}`;
};

export const isEquipmentOnline = (lastComm: string | null | undefined): boolean => {
  return getEquipmentCommunicationStatus(lastComm) !== "offline";
};

export const formatLastSeen = (lastComm: string | null | undefined): string => {
  if (!lastComm) return "nunca";
  const ms = Date.now() - new Date(lastComm).getTime();
  if (Number.isNaN(ms) || ms < 0) return "—";
  const min = Math.floor(ms / 60_000);
  if (min < 1) return "agora";
  if (min < 60) return `há ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `há ${h}h`;
  return `há ${Math.floor(h / 24)}d`;
};

const getRunningFromOutputs = (e: CloudEquipamento): boolean => {
  const payload = e.last_outputs_state ?? "";
  const saidaIndex = (e.saida ?? 1) - 1;
  // Payload curto (poço, 1 dígito): "1" = ligado, "0" = desligado
  if (payload.length === 1) return payload === "1";
  // Payload normal (PLC, 6 dígitos): verifica posição da saída
  if (!/^[01]{1,6}$/.test(payload)) return false;
  if (saidaIndex < 0 || saidaIndex >= payload.length) return false;
  return payload[saidaIndex] === "1";
};

const signalBarsToPercent = (bars: number | null | undefined): number => {
  if (!bars || bars <= 0) return 0;
  if (bars >= 4) return 100;
  if (bars === 3) return 75;
  if (bars === 2) return 50;
  return 25;
};

const buildPumpFromCloud = (
  e: CloudEquipamento,
  log: AutomationLogEntry[],
  tsnnMap: Map<string, string>,
  plcCount: Map<string, number>,
): Pump => {
  const effComm = effectiveLastComm(e, tsnnMap);
  const communicationStatus = getEquipmentCommunicationStatus(effComm, outputsForEquip(e, plcCount));
  const isReachable = communicationStatus !== "offline";

  const isRunning = getRunningFromOutputs(e);
  const name = e.name.toUpperCase();
  const cmdHist = buildCommandHistory(e.id, name, log, 3);
  const stHist = buildStatusHistory(e.id, name, log, 3);

  return {
    id: e.id,
    hwId: e.hw_id,
    rfRadio: (e as { rf_radio?: "R1" | "R2" | "R3" | null }).rf_radio ?? null,
    rfViaRep: (e as { rf_via_rep?: boolean | null }).rf_via_rep ?? null,
    name,
    online: isReachable,
    communicationStatus,
    running: isRunning,
    horimetroMes: "—",
    hasFlow: false,
    lat: e.latitude != null ? Number(e.latitude) : undefined,
    lng: e.longitude != null ? Number(e.longitude) : undefined,
    mode: "manual",
    signalRF: isReachable ? signalBarsToPercent(e.last_signal_bars) : 0,
    voltage: 0,
    current: 0,
    lastCommand: cmdHist[0]
      ? { action: cmdHist[0].action, time: cmdHist[0].time, result: cmdHist[0].result }
      : { action: "Ligar remoto", time: "—", result: "success" as const },
    lastReading: formatTimestamp(e.last_communication),
    lastCommunication: e.last_communication,
    commandHistory: cmdHist,
    statusHistory: stHist,
    actuationOrigin: (e as { last_actuation_origin?: "remote" | "local" | "whatsapp" | "tech_terminal" | null }).last_actuation_origin ?? null,
    localAckAt: (e as { local_ack_at?: string | null }).local_ack_at ?? null,
  };
};

const buildReservoirFromCloud = (
  e: CloudEquipamento,
  plcCount: Map<string, number>,
): Reservoir => {
  const communicationAt = e.last_communication ?? e.level_last_raw_at;
  const communicationStatus = getReservoirCommunicationStatus(communicationAt, outputsForEquip(e, plcCount));
  const isReachable = communicationStatus !== "offline";

  const lvlMaxNum = Number(e.level_max_meters);
  const maxHNum = Number(e.max_height);
  const maxRef = Number.isFinite(lvlMaxNum) && lvlMaxNum > 0
    ? lvlMaxNum
    : (Number.isFinite(maxHNum) && maxHNum > 0 ? maxHNum : 4.0);

  const cal = calibrateLevel({
    raw: e.level_last_raw,
    cal_digital: e.level_cal_digital,
    cal_meters: e.level_cal_meters,
    max_meters: e.level_max_meters,
    max_height: e.max_height,
  });

  return {
    id: e.id,
    name: e.name,
    percent: cal.percent !== null ? Math.round(cal.percent) : 0,
    level: cal.meters !== null ? cal.meters.toFixed(2) : (cal.percent !== null ? "—" : "—"),
    maxLevel: `${maxRef}m`,
    alarm: false,
    signalRF: isReachable ? signalBarsToPercent(e.last_signal_bars) : 0,
    lastReading: formatTimestamp(communicationAt),
    online: isReachable,
  };
};

export interface UseDashboardEquipmentResult {
  pumps: Pump[];
  reservoirs: Reservoir[];
  setPumps: React.Dispatch<React.SetStateAction<Pump[]>>;
  setReservoirs: React.Dispatch<React.SetStateAction<Reservoir[]>>;
  loading: boolean;
  /** snapshots brutos da nuvem (para diagrama de fluxo, popovers) */
  cloudEquipments: CloudEquipamento[];
}

export function useDashboardEquipment(): UseDashboardEquipmentResult {
  const cloud = useCadastrosCloud();
  const farmId = useDefaultFarmId();
  const pendingManualByEq = usePendingManualCommands(farmId);
  const logEntries = useAutomationLog((s) => s.entries);

  // Bombas que já dispararam o RPC de timeout (evita chamar 2x para a mesma transição)
  const localTimeoutFiredRef = useRef<Set<string>>(new Set());

  // ── Reconciliação PONTUAL ────────────────────────────────────────────────
  // Lê do banco SOMENTE os equipamentos informados e reaplica o estado físico
  // confirmado. Usada em dois momentos: quando uma pendência expira (120s) e
  // quando o Realtime reconecta. NÃO é polling: roda por evento, não por relógio.
  const reconcileEquipmentsRef = useRef<(ids: string[]) => Promise<void>>(async () => {});
  reconcileEquipmentsRef.current = async (ids: string[]) => {
    const unique = Array.from(new Set(ids)).filter(Boolean);
    if (!unique.length) return;
    try {
      const { data, error } = await supabase
        .from("equipments")
        .select("id,last_outputs_state,last_communication,desired_running,last_actuation_origin,updated_at")
        .in("id", unique);
      if (error || !data) return;
      setPumps((prev) => {
        let changed = false;
        const byId = new Map((data as Array<Record<string, unknown>>).map((r) => [String(r.id), r]));
        const next = prev.map((p) => {
          const row = byId.get(p.id);
          if (!row) return p;
          // Evento atrasado nunca sobrescreve confirmação mais nova.
          const rowAt = new Date(String(row.updated_at ?? row.last_communication ?? 0)).getTime();
          if (p.lastSyncAt && rowAt && rowAt < p.lastSyncAt) return p;
          const outs = String(row.last_outputs_state ?? "");
          const physical = outs.includes("1");
          if (p.running === physical && !p.pending) return p;
          changed = true;
          return { ...p, running: physical, pending: undefined, pendingStartedAt: undefined,
                   lastSyncAt: rowAt || Date.now() };
        });
        return changed ? next : prev;
      });
    } catch (e) {
      // Falha de rede: não altera o card. O estado físico exibido continua sendo
      // o último confirmado — timeout de comando NÃO é offline.
      console.warn("[reconcileEquipments]", e);
    }
  };
  // Última transição registrada como Local (evita logs duplicados quando a nuvem
  // republica o mesmo `last_actuation_origin = local` em polls subsequentes).
  // Map: equipmentId -> "running:lastCommunicationISO"
  const lastLocalLoggedRef = useRef<Map<string, string>>(new Map());

  const [pumps, setPumps] = useState<Pump[]>([]);
  const [reservoirs, setReservoirs] = useState<Reservoir[]>([]);
  // Mapa equipment_id → horas no mês corrente (atualizado a cada 60s)
  const [horimetroMap, setHorimetroMap] = useState<Record<string, number>>({});

  const cloudPumps = useMemo(
    () => cloud.equipments.filter((e) => e.type === "poco" || e.type === "bombeamento"),
    [cloud.equipments],
  );
  const cloudReservoirs = useMemo(
    () => cloud.equipments.filter((e) => e.type === "nivel"),
    [cloud.equipments],
  );

  // Carrega horímetro do mês corrente para todas as bombas (batch via SQL)
  useEffect(() => {
    if (!farmId || cloudPumps.length === 0) return;
    let cancelled = false;
    const load = async () => {
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      const { data } = await supabase.rpc("get_horimetro_daily", {
        _farm_id: farmId,
        _from: monthStart.toISOString(),
        _to: new Date().toISOString(),
      });
      if (cancelled || !data) return;
      const map: Record<string, number> = {};
      for (const r of data as Array<{ equipment_id: string; hours: number }>) {
        map[r.equipment_id] = (map[r.equipment_id] ?? 0) + Number(r.hours);
      }
      setHorimetroMap(map);
    };
    void load();
    const id = setInterval(load, 300_000); // 5 min — horímetro mensal não muda rápido
    return () => { cancelled = true; clearInterval(id); };
  }, [farmId, cloudPumps.length]);

  // Timeout de comunicação da fazenda (farms.comm_timeout_minutes). Relido ao
  // trocar de fazenda; alimenta getEquipmentCommunicationStatus (offline por TEMPO).
  // Default 15 min quando a coluna vier nula. Sem alterar OTA/agente.
  useEffect(() => {
    if (!farmId) { setActiveFarmCommTimeout(null); return; }
    let cancelled = false;
    void (async () => {
      const { data } = await supabase
        .from("farms")
        .select("comm_timeout_minutes" as any)
        .eq("id", farmId)
        .maybeSingle();
      if (cancelled) return;
      const v = (data as any)?.comm_timeout_minutes;
      setActiveFarmCommTimeout(typeof v === "number" && v > 0 ? v : 15);
    })();
    return () => { cancelled = true; };
  }, [farmId]);

  useEffect(() => {
    const reconcileFromCloud: string[] = [];
    const tsnnMap = buildTsnnLastCommMap(cloud.equipments);
    const plcCount = buildPlcOutputsCountMap(cloud.equipments, cloud.plcs);

    setPumps((prev) => {
      const prevById = new Map(prev.map((p) => [p.id, p]));
      return cloudPumps.map((e) => {
        const communicationStatus = getEquipmentCommunicationStatus(effectiveLastComm(e, tsnnMap), outputsForEquip(e, plcCount));
        const online = communicationStatus !== "offline";

        const old = prevById.get(e.id);
        const cloudRunning = getRunningFromOutputs(e);

        // ─────────────────────────────────────────────────────────────
        // REGRA ÚNICA — REALIDADE FÍSICA VENCE INTENÇÃO
        // ─────────────────────────────────────────────────────────────
        // `last_outputs_state` SÓ muda quando o agente Electron recebe um
        // frame RX REAL da bomba. Portanto, se o RX já bate com o estado
        // desejado, a bomba está fisicamente nesse estado — ignora o
        // pending_command_id e qualquer pending local imediatamente.
        //
        // Só mostra "Ligando…/Desligando…" quando há um comando em curso
        // E a realidade física AINDA NÃO alcançou o desejo.
        let pending = old?.pending;
        let running = cloudRunning;

        const localPending = pending === "turning_on" || pending === "turning_off" || pending === "resetting";
        // Comando manual ativo na tabela `commands` (pending/sent, <90s) —
        // enquanto existir, tratamos o card como "Ligando…/Desligando…" e
        // IGNORAMOS last_outputs_state intermediário do Electron.
        const manualCmd = pendingManualByEq.get(e.id);
        const manualCmdFresh =
          !!manualCmd && Date.now() - new Date(manualCmd.createdAt).getTime() < MANUAL_PENDING_WINDOW_MS;
        // VAZAMENTO CORRIGIDO: `e.pending_command_id` NÃO entra mais aqui.
        // Ele é um marcador de banco SEM LIMITE DE TEMPO: fica não-nulo por
        // comando de automação (que também é type='manual', ver migration
        // 20260625104051) ou por comando que nunca foi fechado. Combinado com
        // `desired_running=false` e a bomba ainda ON, o ramo abaixo derivava
        // `pending = "turning_off"` e o card exibia "Desligando…" sem NENHUM
        // comando do operador — foi o que aconteceu com o POÇO 11 R06 enquanto
        // o comando ia para o POÇO 10 R5. Os dois cards re-renderizam no mesmo
        // tick de Realtime, o que fazia parecer contaminação entre eles.
        // Agora a transição só nasce de um comando FRESCO (<120s) daquele
        // equipment_id — `manualCmdFresh` — ou de um pending local do próprio clique.
        const hasAnyPending = localPending || manualCmdFresh;
        // aviso não-bloqueante de "comando não confirmado" (preserva o anterior)
        let commandUnconfirmedAt = old?.commandUnconfirmedAt;

        if (hasAnyPending) {
          // Determina o estado desejado:
          // 1) Pending local explícito (turning_on/off/resetting) tem prioridade.
          // 2) Senão usa `desired_running` do banco (cross-user).
          let desiredRunning: boolean | null = null;
          if (pending === "turning_on") desiredRunning = true;
          else if (pending === "turning_off" || pending === "resetting") desiredRunning = false;
          else if (typeof e.desired_running === "boolean") desiredRunning = e.desired_running;

          if (desiredRunning === null) {
            if (manualCmdFresh && (old?.pending === "turning_on" || old?.pending === "turning_off")) {
              // Preserva a transição enquanto o comando manual está vivo.
              pending = old.pending;
              running = old.running;
            } else {
              // Sem intenção clara → realidade física manda.
              pending = undefined;
              running = cloudRunning;
            }

          } else if (cloudRunning === desiredRunning) {
            // CONFIRMAÇÃO FÍSICA VENCE SEMPRE — correção do sintoma 4.
            // Antes havia `&& !manualCmdFresh` aqui: mesmo com a bomba já
            // confirmando o estado pedido, a pendência NÃO era limpa enquanto a
            // linha em `commands` seguisse pending/sent (até 120s). Era por isso
            // que o toast "status atualizado (resposta real da bomba)"
            // (PumpTable.tsx:229, disparado pela mudança de last_communication)
            // aparecia com o card ainda preso em "Desligando…". O anti-oscilação
            // de leitura intermediária já é feito por applyConfirmedOffLatch.
            // ✅ Realidade física JÁ alcançou o desejo → libera de imediato.
            // Exceção: se existe comando manual fresh na tabela `commands`
            // (pending/sent, <90s), NÃO liberamos — o Electron pode estar
            // no meio do reforço e escrevendo last_outputs_state=0
            // intermediário. Só liberamos quando o comando sair da fila
            // (executed/cancelled/timeout) OU a janela de 90s expirar.
            pending = undefined;
            running = cloudRunning;
          } else {
            // Ainda não alcançou (ou tem manual fresh mandando manter transição).
            // Se não tinha pending local, deriva da intenção.
            if (!localPending) {
              pending = desiredRunning ? "turning_on" : "turning_off";
            }
            running = old?.running ?? cloudRunning;


            // Timeout duro de 120s para pending local não-reset
            if (localPending && pending !== "resetting") {
              const startedAt = old?.pendingStartedAt ?? 0;
              const elapsed = startedAt ? Date.now() - startedAt : Infinity;
              if (elapsed > PENDING_MAX_MS) {
                // TIMEOUT: nunca prende o card e nunca inventa estado.
                // Limpa a pendência, volta ao último estado FÍSICO confirmado e
                // agenda uma reconciliação PONTUAL só deste equipamento.
                // Não envia comando corretivo: retry pertence ao agente.
                pending = undefined;
                running = cloudRunning;
                commandUnconfirmedAt = Date.now();
                if (!localTimeoutFiredRef.current.has(e.id)) {
                  localTimeoutFiredRef.current.add(e.id);
                  reconcileFromCloud.push(e.id);
                  setTimeout(() => localTimeoutFiredRef.current.delete(e.id), 35_000);
                }
              }
            }
          }
        }
        // Sem pending → realidade física é a verdade absoluta (running = cloudRunning).

        // PROBLEMA 2 — latch anti-oscilação (ver applyConfirmedOffLatch).
        // Passamos a INTENÇÃO derivada, não o desired_running cru do banco: num
        // reset/desligamento o pending já é "resetting"/"turning_off" (intenção =
        // desligar), mesmo que o desired_running do banco esteja true (override
        // local numa bomba local). Sem isto o latch não engatava e o card voltava
        // a "LIGADO"/"Desligando".
        const intentDesired: boolean | null =
          pending === "turning_off" || pending === "resetting" ? false
          : pending === "turning_on" ? true
          : (typeof e.desired_running === "boolean" ? e.desired_running : null);
        const _latch = applyConfirmedOffLatch(
          running, pending, old?.running, old?.confirmedOffAt,
          intentDesired,
          cloudRunning,
        );
        running = _latch.running;
        pending = _latch.pending;
        const confirmedOffAt = _latch.confirmedOffAt;

        const horimetroHoras = horimetroMap[e.id];
        const horimetroLabel = horimetroHoras != null ? `${horimetroHoras.toFixed(1)}h` : "—";

        if (old) {
          return {
            ...old,
            hwId: e.hw_id,
            rfRadio: (e as { rf_radio?: "R1" | "R2" | "R3" | null }).rf_radio ?? null,
            rfViaRep: (e as { rf_via_rep?: boolean | null }).rf_via_rep ?? null,
            name: e.name.toUpperCase(),
            lat: e.latitude != null ? Number(e.latitude) : undefined,
            lng: e.longitude != null ? Number(e.longitude) : undefined,
            online,
            communicationStatus,
            running,
            pending,
            confirmedOffAt,
            pendingStartedAt: pending
              ? (old?.pendingStartedAt ?? Date.now())
              : undefined,
            // some assim que uma confirmação física nova chegar
            commandUnconfirmedAt: pending ? undefined : commandUnconfirmedAt,
            // limpa lastUserConfirmedAt assim que a nuvem confirmar (passamos a confiar nela)
            lastUserConfirmedAt:
              old.lastUserConfirmedAt &&
              e.last_communication &&
              new Date(e.last_communication).getTime() > old.lastUserConfirmedAt
                ? undefined
                : old.lastUserConfirmedAt,
            actuationOrigin: (e.last_actuation_origin as "remote" | "local" | "whatsapp" | "tech_terminal" | null) ?? null,
            localAckAt: (e as { local_ack_at?: string | null }).local_ack_at ?? null,
            commandBlockedUntil: e.command_blocked_until ?? null,
            lastCommunication: e.last_communication,
            commandLockUntil: (e as { command_lock_until?: string | null }).command_lock_until
              ? new Date((e as { command_lock_until?: string }).command_lock_until!).getTime() : undefined,
            lastConfirmedTransitionAt: (e as { last_confirmed_transition_at?: string | null }).last_confirmed_transition_at
              ? new Date((e as { last_confirmed_transition_at?: string }).last_confirmed_transition_at!).getTime() : undefined,
            lastReading: formatTimestamp(e.last_communication),
            signalRF: online ? signalBarsToPercent(e.last_signal_bars) : 0,
            voltage: 0,
            current: 0,
            horimetroMes: horimetroLabel,
          };
        }
        return { ...buildPumpFromCloud(e, logEntries, tsnnMap, plcCount), horimetroMes: horimetroLabel };
      });
    });

    // Timeout: reconciliação PONTUAL do(s) equipamento(s) afetado(s).
    // O frontend NÃO envia comando corretivo nem retry — isso é do agente.
    if (reconcileFromCloud.length) void reconcileEquipmentsRef.current(reconcileFromCloud);
  }, [cloudPumps, cloud.equipments, cloud.plcs, horimetroMap, logEntries, pendingManualByEq]);

  useEffect(() => {
    const tick = () => {
      const tsnnMap = buildTsnnLastCommMap(cloud.equipments);
      const plcCount = buildPlcOutputsCountMap(cloud.equipments, cloud.plcs);
      // Coleta bombas que estouraram 120s sem confirmação para disparar RPC
      const reconcileIds: string[] = [];
      // Coleta transições detectadas como Local pela nuvem (sem timeout local)
      const localFromCloud: { equipmentId: string; name: string; running: boolean; ts: string }[] = [];

      setPumps((prev) => {
        let changed = false;
        const next = prev.map((p) => {
          const cloudEq = cloudPumps.find((e) => e.id === p.id);
          if (!cloudEq) return p;
          const communicationStatus = getEquipmentCommunicationStatus(effectiveLastComm(cloudEq, tsnnMap), outputsForEquip(cloudEq, plcCount));
          const online = communicationStatus !== "offline";

          const cloudRunning = getRunningFromOutputs(cloudEq);

          // REGRA ÚNICA — REALIDADE FÍSICA VENCE INTENÇÃO (mesma do useEffect).
          let pending = p.pending;
          let running = cloudRunning;

          const localPending = pending === "turning_on" || pending === "turning_off" || pending === "resetting";
          const manualCmd = pendingManualByEq.get(p.id);
          const manualCmdFresh =
            !!manualCmd && Date.now() - new Date(manualCmd.createdAt).getTime() < MANUAL_PENDING_WINDOW_MS;
          // Mesma correção do bloco acima: marcador de banco sem limite de
          // tempo não pode gerar transição visual em card não comandado.
          const hasAnyPending = localPending || manualCmdFresh;
          let commandUnconfirmed = p.commandUnconfirmedAt;

          if (hasAnyPending) {
            let desiredRunning: boolean | null = null;
            if (pending === "turning_on") desiredRunning = true;
            else if (pending === "turning_off" || pending === "resetting") desiredRunning = false;
            else if (typeof cloudEq.desired_running === "boolean") desiredRunning = cloudEq.desired_running;

            if (desiredRunning === null) {
              if (manualCmdFresh && (p.pending === "turning_on" || p.pending === "turning_off")) {
                pending = p.pending;
                running = p.running;
              } else {
                pending = undefined;
                running = cloudRunning;
              }
            } else if (cloudRunning === desiredRunning) {
            // CONFIRMAÇÃO FÍSICA VENCE SEMPRE — correção do sintoma 4.
            // Antes havia `&& !manualCmdFresh` aqui: mesmo com a bomba já
            // confirmando o estado pedido, a pendência NÃO era limpa enquanto a
            // linha em `commands` seguisse pending/sent (até 120s). Era por isso
            // que o toast "status atualizado (resposta real da bomba)"
            // (PumpTable.tsx:229, disparado pela mudança de last_communication)
            // aparecia com o card ainda preso em "Desligando…". O anti-oscilação
            // de leitura intermediária já é feito por applyConfirmedOffLatch.
              // ✅ Realidade física já alcançou o desejo → libera de imediato.
              // Enquanto houver comando manual fresh (<90s), NÃO liberamos —
              // last_confirmed_state pode ser leitura intermediária do reforço.
              pending = undefined;
              running = cloudRunning;
            } else {

              if (!localPending) {
                pending = desiredRunning ? "turning_on" : "turning_off";
              }
              running = p.running;

              if (localPending && pending !== "resetting") {
                const startedAt = p.pendingStartedAt ?? 0;
                const elapsed = startedAt ? Date.now() - startedAt : Infinity;
                if (elapsed > PENDING_MAX_MS) {
                  // TIMEOUT: limpa a pendência daquele ÚNICO poço, mantém o
                  // último estado físico confirmado e pede reconciliação pontual.
                  // Sem comando corretivo, sem RESET, sem marcar offline.
                  pending = undefined;
                  running = cloudRunning;
                  commandUnconfirmed = Date.now();
                  if (!localTimeoutFiredRef.current.has(p.id)) {
                    localTimeoutFiredRef.current.add(p.id);
                    reconcileIds.push(p.id);
                    setTimeout(() => localTimeoutFiredRef.current.delete(p.id), 35_000);
                  }
                }
              }
            }
          }


          // PROBLEMA 2 — latch anti-oscilação (mesma regra do bloco Realtime).
          // Passa a INTENÇÃO derivada (não o desired_running cru): pending
          // resetting/turning_off = desligar, mesmo com desired_running=true no
          // banco (override local). É o que faz o latch engatar no forçado.
          const intentDesired2: boolean | null =
            pending === "turning_off" || pending === "resetting" ? false
            : pending === "turning_on" ? true
            : (typeof cloudEq.desired_running === "boolean" ? cloudEq.desired_running : null);
          const _latch2 = applyConfirmedOffLatch(
            running, pending, p.running, p.confirmedOffAt,
            intentDesired2,
            cloudRunning,
          );
          running = _latch2.running;
          pending = _latch2.pending;
          const confirmedOffAt = _latch2.confirmedOffAt;

          // limpa lastUserConfirmedAt quando a nuvem confirmar
          const lastCommMs = cloudEq.last_communication
            ? new Date(cloudEq.last_communication).getTime()
            : 0;
          const nextConfirmedAt =
            p.lastUserConfirmedAt && lastCommMs > p.lastUserConfirmedAt
              ? undefined
              : p.lastUserConfirmedAt;

          const newActuationOrigin =
            (cloudEq.last_actuation_origin as "remote" | "local" | "whatsapp" | "tech_terminal" | null) ?? null;

          // Detecta acionamento Local recém-confirmado pela nuvem (sem timeout local
          // ter disparado). Caso típico: a RPC apply_pump_telemetry marcou origin=local
          // quando a bomba mudou de estado sem comando remoto correlato.
          if (
            newActuationOrigin === "local" &&
            cloudEq.last_communication &&
            !(pending === "turning_on" || pending === "turning_off" || pending === "resetting")
          ) {
            const sig = `${cloudRunning ? "1" : "0"}:${cloudEq.last_communication}`;
            const prevSig = lastLocalLoggedRef.current.get(p.id);
            const stateChanged = p.running !== cloudRunning || p.actuationOrigin !== "local";
            if (prevSig !== sig && stateChanged) {
              lastLocalLoggedRef.current.set(p.id, sig);
              localFromCloud.push({
                equipmentId: p.id,
                name: p.name,
                running: cloudRunning,
                ts: cloudEq.last_communication,
              });
            }
          }

          const newSignalRF = online ? signalBarsToPercent(cloudEq.last_signal_bars) : 0;
          const newCommandBlockedUntil = cloudEq.command_blocked_until ?? null;
          const newLastReading = formatTimestamp(cloudEq.last_communication);
          const newLocalAckAt = (cloudEq as { local_ack_at?: string | null }).local_ack_at ?? null;

          // PERFORMANCE: se nada mudou, devolve o mesmo objeto — evita que
          // PumpTable/WaterBalanceCard/IndicatorsMiniSummary re-renderizem
          // a cada 5s sem motivo. Re-render só ocorre em mudança real.
          const samePendingStart = pending
            ? (p.pendingStartedAt ?? Date.now()) === (p.pendingStartedAt ?? Date.now())
            : p.pendingStartedAt === undefined;
          if (
            p.online === online &&
            p.communicationStatus === communicationStatus &&
            p.running === running &&
            p.pending === pending &&
            samePendingStart &&
            p.lastUserConfirmedAt === nextConfirmedAt &&
            p.actuationOrigin === newActuationOrigin &&
            p.commandBlockedUntil === newCommandBlockedUntil &&
            p.lastCommunication === cloudEq.last_communication &&
            p.lastReading === newLastReading &&
            p.signalRF === newSignalRF &&
            p.localAckAt === newLocalAckAt &&
            p.commandUnconfirmedAt === commandUnconfirmed
          ) {
            return p;
          }

          changed = true;
          return {
            ...p,
            online,
            communicationStatus,
            running,
            pending,
            confirmedOffAt,
            pendingStartedAt: pending
              ? (p.pendingStartedAt ?? Date.now())
              : undefined,
            commandUnconfirmedAt: pending ? undefined : commandUnconfirmed,
            lastUserConfirmedAt: nextConfirmedAt,
            actuationOrigin: newActuationOrigin,
            commandBlockedUntil: newCommandBlockedUntil,
            lastCommunication: cloudEq.last_communication,
            commandLockUntil: (cloudEq as { command_lock_until?: string | null }).command_lock_until
              ? new Date((cloudEq as { command_lock_until?: string }).command_lock_until!).getTime() : undefined,
            lastConfirmedTransitionAt: (cloudEq as { last_confirmed_transition_at?: string | null }).last_confirmed_transition_at
              ? new Date((cloudEq as { last_confirmed_transition_at?: string }).last_confirmed_transition_at!).getTime() : undefined,
            lastReading: newLastReading,
            signalRF: newSignalRF,
            voltage: 0,
            current: 0,
            localAckAt: newLocalAckAt,
          };
        });
        return changed ? next : prev;
      });

      // Timeout: reconciliação PONTUAL apenas dos poços afetados. Sem comando
      // corretivo, sem RPC de "acionamento local" inferida por timeout (inferir
      // LOCAL a partir de silêncio foi justamente a origem dos eventos falsos).
      if (reconcileIds.length) void reconcileEquipmentsRef.current(reconcileIds);

      // Registra no log toda transição que a nuvem confirmou como Local
      // (acionamento físico no painel detectado pela RPC apply_pump_telemetry).
      for (const lc of localFromCloud) {
        logEvent({
          equipmentId: lc.equipmentId,
          pump: lc.name,
          action: lc.running ? "Ligada" : "Desligada",
          origin: "Manual", // = local no DB
          user: "", // acionamento físico no painel: usuário desconhecido
          result: "success",
        });
        notify.warn("Equipamentos", `${lc.name}: ${lc.running ? "ligada" : "desligada"} localmente no painel físico`);
      }
    };

    tick();
    // Tick adaptativo: 15s em mobile/tablet (iPad), 5s em desktop.
    // Reduz carga do processador no iPad sem prejudicar UX —
    // Realtime ainda atualiza imediato; este tick só re-avalia pending/offline.
    const isMobile = typeof window !== "undefined" && window.innerWidth < 1024;
    const tickMs = isMobile ? 15_000 : 5_000;
    const intervalId = setInterval(tick, tickMs);
    return () => clearInterval(intervalId);
  }, [cloudPumps, cloud.equipments, cloud.plcs, pendingManualByEq]);

  // Tick a cada 5–15s para reavaliar offline mesmo sem novo realtime
  const [reservoirTick, setReservoirTick] = useState(0);
  useEffect(() => {
    const isMobile = typeof window !== "undefined" && window.innerWidth < 1024;
    const tickMs = isMobile ? 15_000 : 5_000;
    const id = setInterval(() => setReservoirTick((n) => n + 1), tickMs);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const plcCount = buildPlcOutputsCountMap(cloud.equipments, cloud.plcs);
    setReservoirs((prev) => {
      const prevById = new Map(prev.map((r) => [r.id, r]));
      let changed = false;
      const next = cloudReservoirs.map((e) => {
        const communicationAt = e.last_communication ?? e.level_last_raw_at;
        const communicationStatus = getReservoirCommunicationStatus(communicationAt, outputsForEquip(e, plcCount));
        const online = communicationStatus !== "offline";

        const old = prevById.get(e.id);
        const lvlMaxNum = Number(e.level_max_meters);
        const maxHNum = Number(e.max_height);
        const maxRef = Number.isFinite(lvlMaxNum) && lvlMaxNum > 0
          ? lvlMaxNum
          : (Number.isFinite(maxHNum) && maxHNum > 0 ? maxHNum : 4.0);
        const cal = calibrateLevel({
          raw: e.level_last_raw,
          cal_digital: e.level_cal_digital,
          cal_meters: e.level_cal_meters,
          max_meters: e.level_max_meters,
          max_height: e.max_height,
        });
        const level = cal.meters !== null ? cal.meters.toFixed(2) : "—";
        const percent = cal.percent !== null ? Math.round(cal.percent) : 0;
        const signalRF = online ? signalBarsToPercent(e.last_signal_bars) : 0;
        const lastReading = formatTimestamp(communicationAt);
        const maxLevel = `${maxRef}m`;

        if (old) {
          // Idempotência: se nada mudou, mantém referência (evita re-render).
          if (
            old.name === e.name &&
            old.percent === percent &&
            old.level === level &&
            old.maxLevel === maxLevel &&
            old.signalRF === signalRF &&
            old.lastReading === lastReading &&
            old.online === online
          ) {
            return old;
          }
          changed = true;
          return { ...old, name: e.name, percent, level, maxLevel, signalRF, lastReading, online };
        }
        changed = true;
        return buildReservoirFromCloud(e, plcCount);
      });
      if (!changed && next.length === prev.length) return prev;
      return next;
    });
  }, [cloudReservoirs, reservoirTick, cloud.equipments]);

  useEffect(() => {
    setPumps((prev) =>
      prev.map((p) => {
        const cmdHist = buildCommandHistory(p.id, p.name, logEntries, 3);
        const stHist = buildStatusHistory(p.id, p.name, logEntries, 3);
        return {
          ...p,
          commandHistory: cmdHist,
          statusHistory: stHist,
          lastCommand: cmdHist[0]
            ? { action: cmdHist[0].action, time: cmdHist[0].time, result: cmdHist[0].result }
            : p.lastCommand,
        };
      }),
    );
  }, [logEntries]);

  // ─── Vazão/Consumo ────────────────────────────────────────────────
  // Enriquece cada Pump com hasFlow/flowRate/dailyConsumption a partir do
  // equipamento tipo 'vazao' que compartilha o mesmo plc_group_id.
  // O totalizador vem do PLC via N2 (m³), gravado por apply_flow_telemetry.
  // Consumo do mês corrente por equipment_id (soma de daily_consumption).
  const [monthByEq, setMonthByEq] = useState<Map<string, number>>(new Map());
  useEffect(() => {
    if (!farmId) return;
    let cancelled = false;
    const load = async () => {
      const today = new Date();
      const first = new Date(today.getFullYear(), today.getMonth(), 1);
      const iso = first.toISOString().slice(0, 10);
      const { data } = await supabase
        .from("daily_consumption")
        .select("equipment_id,total_m3")
        .eq("farm_id", farmId)
        .gte("date", iso);
      if (cancelled) return;
      const map = new Map<string, number>();
      for (const r of (data ?? []) as { equipment_id: string; total_m3: number | null }[]) {
        map.set(r.equipment_id, (map.get(r.equipment_id) ?? 0) + Number(r.total_m3 ?? 0));
      }
      setMonthByEq(map);
    };
    void load();
    const id = window.setInterval(load, 60_000);
    return () => { cancelled = true; window.clearInterval(id); };
  }, [farmId]);

  useEffect(() => {
    const flowByPlc = new Map<string, { accum: number; daily: number }>();
    for (const e of cloud.equipments) {
      if (e.type !== "vazao" || !e.plc_group_id) continue;
      const accum = Number(e.flow_accum_m3 ?? 0);
      const start = Number(e.flow_daily_start_m3 ?? accum);
      flowByPlc.set(e.plc_group_id, { accum, daily: Math.max(0, accum - start) });
    }
    setPumps((prev) => {
      let changed = false;
      const next = prev.map((p) => {
        const cloudEq = cloud.equipments.find((e) => e.id === p.id);
        const plcId = cloudEq?.plc_group_id ?? null;
        const flow = plcId ? flowByPlc.get(plcId) : undefined;
        const hasFlow = !!flow;
        const flowRate = flow ? `${flow.accum.toLocaleString("pt-BR")} m³` : undefined;
        const dailyConsumption = flow ? `${flow.daily.toLocaleString("pt-BR")} m³` : undefined;

        // Modo Vazão/Consumo direto no equipamento (poço/bomba).
        const vazaoMode = (cloudEq?.vazao_mode ?? "off") as "off" | "estimated" | "real";
        let vazaoAtualM3h = 0;
        if (vazaoMode === "real") {
          vazaoAtualM3h = Number(cloudEq?.flow_rate_m3h ?? 0);
        } else if (vazaoMode === "estimated") {
          vazaoAtualM3h = p.running ? Number(cloudEq?.vazao_cadastrada_m3h ?? 0) : 0;
        }
        const consumoMesM3FromDaily = monthByEq.get(p.id) ?? 0;
        const flowTotalM3 = Number(cloudEq?.flow_total_m3 ?? 0);
        // Consumo do mês = soma dos daily_consumption fechados no mês
        // (cada reset gera uma linha) + o parcial pós-último-reset (flow_total_m3).
        const consumoMesM3 = vazaoMode === "real"
          ? consumoMesM3FromDaily + flowTotalM3
          : consumoMesM3FromDaily;

        if (
          p.hasFlow === hasFlow &&
          p.flowRate === flowRate &&
          p.dailyConsumption === dailyConsumption &&
          p.vazaoMode === vazaoMode &&
          p.vazaoAtualM3h === vazaoAtualM3h &&
          p.consumoMesM3 === consumoMesM3 &&
          p.flowTotalM3 === flowTotalM3
        ) return p;
        changed = true;
        return { ...p, hasFlow, flowRate, dailyConsumption, vazaoMode, vazaoAtualM3h, consumoMesM3, flowTotalM3 };
      });
      return changed ? next : prev;
    });
  }, [cloud.equipments, setPumps, monthByEq]);


  return {
    pumps,
    reservoirs,
    setPumps,
    setReservoirs,
    loading: cloud.loading,
    cloudEquipments: cloud.equipments,
    // Saúde da assinatura, para o indicador técnico do header (diagnóstico puro).
    realtimeHealth: cloud.realtimeHealth,
    lastPhysicalReadAt: cloud.lastPhysicalReadAt,
  };
}
