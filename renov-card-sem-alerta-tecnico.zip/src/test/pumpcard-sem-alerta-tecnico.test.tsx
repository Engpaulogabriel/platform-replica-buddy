// @vitest-environment jsdom
// O card do cliente mostra SOMENTE estado físico. Nenhum selo técnico de
// comando pode chegar ao DOM — nem como texto, title, aria-label ou tooltip.
import { describe, it, expect, vi } from "vitest";
import { render, screen, cleanup, act } from "@testing-library/react";
import type { Pump } from "@/components/dashboard/PumpTable";

vi.mock("@/contexts/MaintenanceContext", () => ({ useOpenMaintenance: () => ({ getForEquipment: () => null }) }));
vi.mock("@/contexts/MasterManagerContext", () => ({ usePermission: () => true }));
vi.mock("@/contexts/AuthContext", () => ({ useAuth: () => ({ user: { id: "u1" } }) }));
vi.mock("@/integrations/supabase/client", () => ({
  supabase: { from: () => ({ select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: null, error: null }) }) }) }),
              rpc: async () => ({ data: false, error: null }) },
}));
vi.mock("@/lib/realtimeKillSwitch", () => ({
  getRealtimeChannel: () => ({ on: () => ({ subscribe: () => ({}) }) }),
  removeRealtimeChannel: async () => {},
}));

const { PumpCard } = await import("@/components/dashboard/PumpCard");
const { TechnicalTelemetryProvider } = await import("@/hooks/useTechnicalTelemetry");

const base = (o: Partial<Pump> = {}): Pump => ({
  id: "p7", name: "POÇO 07 R1", running: true, online: true,
  communicationStatus: "online", lastCommunication: new Date().toISOString(),
  signalRF: 72, mode: "manual", sector: "", farmId: "f", ...o,
} as unknown as Pump);

async function draw(p: Pump, extra: Record<string, unknown> = {}) {
  cleanup();
  render(
    <TechnicalTelemetryProvider>
      <PumpCard pump={p} expanded refreshing={false} lastFailed={false}
        isGuarded={false} userOnline maintenanceActive={false}
        farms={[]} sectors={[]} guardFarmId={null} virtualize={false}
        onToggle={() => {}} onRefresh={() => {}} onOpenDialog={() => {}} onToggleExpand={() => {}}
        {...extra} />
    </TechnicalTelemetryProvider>);
  await act(async () => {});
}

/** texto + TODOS os atributos legíveis pelo usuário */
function superficie(): string {
  const at: string[] = [];
  document.body.querySelectorAll("*").forEach((el) => {
    for (const a of ["title","aria-label","alt","data-tooltip","placeholder"]) {
      const v = el.getAttribute(a); if (v) at.push(v);
    }
  });
  return `${document.body.textContent ?? ""}\n${at.join("\n")}`;
}

const PROIBIDOS: Array<[string, RegExp]> = [
  ["Comando não confirmado", /comando n[ãa]o confirmado/i],
  ["Comando pendente",       /comando pendente/i],
  ["Aguardando confirmação", /aguardando confirma/i],
  ["aguardando nova leitura",/aguardando nova leitura/i],
  ["timeout",                /timeout/i],
  ["falhou",                 /falhou/i],
  ["falha de comando",       /falha de comando|erro de comando|falha de comm/i],
  ["retry",                  /retry|retentativa/i],
  ["command_pending",        /command_pending/i],
  ["command_blocked_until",  /command_blocked_until/i],
  ["Ligando…/Desligando…",   /ligando\.\.\.|desligando\.\.\.|resetando\.\.\./i],
];

/** cenários com pendência/falha, em todos os estados físicos */
const PENDENCIAS = [
  { nome: "pending turning_on",        p: { pending: "turning_on", pendingStartedAt: Date.now() } },
  { nome: "pending turning_off",       p: { pending: "turning_off", pendingStartedAt: Date.now() } },
  { nome: "pending resetting",         p: { pending: "resetting" } },
  { nome: "commandUnconfirmedAt",      p: { commandUnconfirmedAt: Date.now() } },
  { nome: "commandBlockedUntil",       p: { commandBlockedUntil: Date.now() + 30_000 } },
  { nome: "commandLockUntil",          p: { commandLockUntil: Date.now() + 30_000 } },
];

describe("1 e 5. nenhum selo técnico no DOM do card", () => {
  for (const c of PENDENCIAS) {
    it(`${c.nome}: nada técnico em texto, title ou aria-label`, async () => {
      await draw(base(c.p as Partial<Pump>));
      const s = superficie();
      for (const [n, re] of PROIBIDOS)
        expect(s, `vazou "${n}" com ${c.nome}`).not.toMatch(re);
    });
  }

  it("com lastFailed e refreshResult=fail também não aparece nada", async () => {
    await draw(base(), { lastFailed: true, refreshResult: "fail" });
    const s = superficie();
    for (const [n, re] of PROIBIDOS)
      expect(s, `vazou "${n}"`).not.toMatch(re);
  });
});

describe("2 a 4. o card mostra o último estado físico conhecido", () => {
  it("2. pendência + último estado LIGADO → verde/Ligado", async () => {
    await draw(base({ running: true, pending: "turning_off" } as Partial<Pump>));
    // o estado é comunicado pela COR; não há rótulo permanente no card
    expect(document.querySelector("div > div")?.className).toMatch(/bg-primary/);
    expect(document.body.textContent).not.toMatch(/Desligando/i);
  });

  it("3. pendência + último estado DESLIGADO → vermelho/Desligado", async () => {
    await draw(base({ running: false, pending: "turning_on" } as Partial<Pump>));
    const cls = document.querySelector("div > div")?.className ?? "";
    expect(cls).not.toMatch(/bg-primary\/25/);
    expect(document.body.textContent).not.toMatch(/Ligando/i);
  });

  it("4. telemetria vencida → OFFLINE cinza, sem alerta de comando", async () => {
    await draw(base({ online: false, communicationStatus: "offline",
                      commandUnconfirmedAt: Date.now() } as Partial<Pump>));
    expect(document.body.textContent).toMatch(/Offline/i);
    const s = superficie();
    for (const [n, re] of PROIBIDOS)
      expect(s, `vazou "${n}" no offline`).not.toMatch(re);
  });

  it("a pendência não muda a cor do card", async () => {
    await draw(base({ running: true } as Partial<Pump>));
    const semPend = document.querySelector("div > div")?.className;
    await draw(base({ running: true, pending: "turning_off",
                      commandUnconfirmedAt: Date.now() } as Partial<Pump>));
    expect(document.querySelector("div > div")?.className).toBe(semPend);
  });
});

describe("6. nada mais do card foi alterado", () => {
  it("RefreshCw e seu ciclo continuam", async () => {
    await draw(base());
    expect(screen.getByTestId("pump-refresh-button").querySelector("svg")?.getAttribute("class"))
      .toContain("lucide-refresh-cw");
    await draw(base(), { refreshing: true });
    expect(screen.getByTestId("pump-refresh-button").querySelector("svg")?.getAttribute("class"))
      .toContain("animate-spin");
  });

  it("barras de comunicação continuam", async () => {
    await draw(base());
    expect(screen.queryByTestId("comm-bars")).not.toBeNull();
  });

  it("selo LOCAL continua para atuação local", async () => {
    await draw(base({ actuationOrigin: "local" } as Partial<Pump>));
    expect(document.body.textContent).toContain("LOCAL");
  });

  it("manutenção continua bloqueando e exibindo", async () => {
    const onToggle = vi.fn();
    await draw(base({ running: false } as Partial<Pump>), { inMaintenance: true, onToggle });
    expect(document.body.textContent).toMatch(/MANUTENÇÃO/);
    (document.querySelector('[role="switch"]') as HTMLElement)?.click();
    expect(onToggle).not.toHaveBeenCalled();
  });

  it("o toggle continua funcionando com pendência", async () => {
    const onToggle = vi.fn();
    await draw(base({ running: false, commandUnconfirmedAt: Date.now() } as Partial<Pump>), { onToggle });
    (document.querySelector('[role="switch"]') as HTMLElement)?.click();
    expect(onToggle).toHaveBeenCalledWith("p7");
  });
});
